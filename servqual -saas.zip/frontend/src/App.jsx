import React, { useState, useEffect } from 'react';

function App() {
  const [dims, setDims] = useState([]);

  useEffect(() => {
    fetch('http://127.0.0.1:8000/api/v1/dimensions/')
      .then(r => r.json())
      .then(data => setDims(data))
      .catch(() => setDims([]));
  }, []);

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Dimensiones SERVQUAL</h1>
      <ul>
        {dims.map(d => (
          <li key={d.id}>
            <strong>{d.nombre}</strong>: {d.descripcion}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
