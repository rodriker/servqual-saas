from rest_framework import serializers
from .models import Encuesta, Pregunta, Respuesta

class PreguntaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pregunta
        fields = ['id', 'dimension', 'texto']

class EncuestaSerializer(serializers.ModelSerializer):
    preguntas = PreguntaSerializer(many=True, read_only=True)

    class Meta:
        model = Encuesta
        fields = ['id', 'titulo', 'creada', 'preguntas']
