from django.urls import path
from .views import HelloWorld, ListDimensions, EncuestaListCreate, EncuestaDetail

urlpatterns = [
    path('<str:version>/hello/', HelloWorld.as_view(), name='hello-world'),
    path('<str:version>/dimensions/', ListDimensions.as_view(), name='list-dimensions'),

    # — CRUD de Encuestas —
    path('<str:version>/surveys/', EncuestaListCreate.as_view(), name='survey-list-create'),
    path('<str:version>/surveys/<int:id>/', EncuestaDetail.as_view(), name='survey-detail'),
]
